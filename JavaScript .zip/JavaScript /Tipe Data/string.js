// 1. escaping string (\' \" \\ \n \r \t \ b \f')
let data1 = 'ucup berkata "apa kabar dunia"';
console.log(data1);
let data2 = "udin berkata \"sepontan uhuuy\"";
console.log(data2);
let data3 = "maman berenang di sungai, \ndia hanyut"
console.log(data3);

//  2. literal string (template literal string.js)