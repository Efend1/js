//tipe data 
// String
let dataString = "Ini adalah string";
console.log(dataString);
console.log(typeof dataString);

//Number
let dataNumber = 17.3839;
console.log(dataNumber);
console.log(typeof dataNumber);

//Boolean
let dataBoolean = false;
console.log(dataBoolean);
console.log(typeof dataBoolean);

//mengubah data string menjadi Number
dataString = 4;
console.log(dataString);
console.log(typeof dataString);

//undefined
let dataKosong;
console.log(dataKosong);
console.log(typeof dataKosong);
dataKosong = "isi";
console.log(dataKosong);
console.log(typeof dataKosong);
